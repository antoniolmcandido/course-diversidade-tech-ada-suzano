

<p>
    <img src="https://banyantreatmentcenter.com/wp-content/uploads/2018/10/alcohol-1200x480.jpg"/>
</p>

<h1 align="center"> Graphic Analisys: Student-Alcohol-Consumption </h1>

<p align="center">Análise Grágica de dados de estudantes do Ensino Médio, desenvolvida para a disciplina de Técnicas de Programação II da Formação de Pyhton e Dados - Ada<p>
<p align="center">
    <a href="##Autores">Autores</a> |
    <a href="##Tecnologias">Tecnologias</a> |
    <a href="##Projeto">Projeto</a> 
</p>
<br>

---

# Autores

- [Antonio Leandro Martins Candido](https://github.com/antoniolmcandido)
- [Augusto Vinicius da Silva](https://github.com/Vinicius999)
- [Hugo Rafael Freitas Negrão](https://github.com/hugonegrao) 

<br>

---

## Tecnologias

<p style='margin: 16px 4px 32px;'>
    <a href="https://www.python.org/" target="_blank" rel="noreferrer">
        <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/python/python-original.svg" alt="Vini-python" width="40" height="40" />
    </a>
	<a href="https://jupyter.org/" target="_blank" rel="noreferrer">
        <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/jupyter/jupyter-original-wordmark.svg" alt="jupyter" width="40" height="40" />
    </a>
</p>

<br>

---

## Projeto

<div>
   <a href="https://github.com/Vinicius999/EDA-IMDb-Top1000-Films/blob/main/Projeto_TopFilmes.ipynb">
        <h5>
            Graphic Analisys: Student-Alcohol-Consumption
        </h5>
    </a> 
</div>

